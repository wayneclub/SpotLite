# spotlite/analysis/preprocess/__init__.py
from __future__ import annotations
from typing import List

from .restaurant_gmap_preprocessor import RestaurantGMapReviewPreprocessor
from .base_preprocessor import ReviewPreprocessorBase

_PREPROCESSORS: List[ReviewPreprocessorBase] = [
    RestaurantGMapReviewPreprocessor(),
    # 未來可以在這裡加更多
]


def get_preprocessor(source: str, domain: str) -> ReviewPreprocessorBase | None:
    for p in _PREPROCESSORS:
        if p.supports(source, domain):
            return p
    return None
