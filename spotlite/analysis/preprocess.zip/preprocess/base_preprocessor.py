# spotlite/analysis/preprocess/base_preprocessor.py
from __future__ import annotations
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Tuple

from spotlite.analysis.preprocess.text_splitters import split_text_and_block
from spotlite.analysis.preprocess.structured_parsers import StructuredReviewParser


class ReviewPreprocessorBase(ABC):
    """
    處理一整個 place 的評論：
      - 拆 pure text vs structured
      - 呼叫對應的 StructuredReviewParser
      - 回傳：
          - updated unified dict (加上 structured_stats 等)
          - plain_reviews list
          - structured_reviews list
    """

    def __init__(self, parser: StructuredReviewParser | None = None) -> None:
        self.parser = parser

    def preprocess_place(
        self,
        unified: Dict[str, Any],
    ) -> Tuple[Dict[str, Any], List[Dict[str, Any]], List[Dict[str, Any]]]:
        """
        統一入口：吃進 unified place dict，吐回：
          - new_unified: 有需要可加上 structured 統計結果
          - plain_reviews: 用來做 NLP / aspect / keywords 的一般評論
          - structured_reviews: 之後拿來做統計 (Food/Service 分數分佈等)
        """
        reviews = unified.get("reviews", [])
        plain: List[Dict[str, Any]] = []
        structured: List[Dict[str, Any]] = []

        for rev in reviews:
            rev_dict = rev if isinstance(rev, dict) else {"text": str(rev)}
            text = (
                rev_dict.get("text")
                or rev_dict.get("reviewText")
                or rev_dict.get("content")
                or rev_dict.get("body")
                or ""
            )
            free_text, block = split_text_and_block(text)

            rev_dict["text"] = free_text

            if block and self.parser is not None:
                parsed = self.parser.parse_block(block)
                if parsed:
                    rev_dict.setdefault("structured", {}).update(parsed)
                    structured.append(rev_dict)
                else:
                    plain.append(rev_dict)
            else:
                plain.append(rev_dict)

        new_unified = dict(unified)
        new_unified["reviews"] = plain
        # 可以在這裡做 structured 統計（平均 Food/Service/Atmosphere 分數等）
        return new_unified, plain, structured

    @abstractmethod
    def supports(self, source: str, domain: str) -> bool:
        """
        給 factory 用：判斷這個 Preprocessor 是否支援某個 (source, domain)。
        """
        raise NotImplementedError
