# spotlite/analysis/preprocess/restaurant_gmap_preprocessor.py
from __future__ import annotations
from typing import Any, Dict, List, Tuple

from spotlite.analysis.preprocess.base_preprocessor import ReviewPreprocessorBase
from spotlite.analysis.preprocess.structured_parsers import RestaurantGMapStructuredParser


class RestaurantGMapReviewPreprocessor(ReviewPreprocessorBase):

    def __init__(self) -> None:
        super().__init__(parser=RestaurantGMapStructuredParser())

    def supports(self, source: str, domain: str) -> bool:
        return source == "google_maps" and domain == "restaurant"

    def preprocess_place(self, unified: Dict[str, Any]):
        """
        Google Maps 餐廳 reviews 預處理：
        - 拆成 plain_reviews（純文字）
        - structured_reviews（Food:5, Service:4, ...）
        """

        raw_reviews = unified.get("reviews", [])
        plain_reviews = []
        structured_reviews = []

        for r in raw_reviews:
            text = r.get("text", "")

            # 用 Parser 把 structured block 解析出來
            parsed_struct = self.parser.extract_structured_block(text)
            if parsed_struct:
                structured_reviews.append(parsed_struct)

            # 把純文字版本清掉 structured block
            cleaned = self.parser.remove_structured_block(text)
            if cleaned.strip():
                plain_reviews.append(cleaned.strip())

        unified_proc = dict(unified)
        unified_proc["processed_reviews"] = plain_reviews
        unified_proc["structured_reviews"] = structured_reviews

        return unified_proc, plain_reviews, structured_reviews
