# spotlite/analysis/preprocess/text_splitters.py
from __future__ import annotations
from typing import Tuple
import re

STRUCTURED_PATTERNS = [
    r"Meal type:",
    r"Price per person:",
    r"Food:\s*\d",
    r"Service:\s*\d",
    r"Atmosphere:\s*\d",
    r"Noise level:",
    r"Wait time:",
    r"Parking space:",
    r"Parking options:",
    r"Recommended dishes?:",
]

_COMPILED = [re.compile(p, flags=re.IGNORECASE) for p in STRUCTURED_PATTERNS]


def looks_structured(text: str) -> bool:
    """判斷這則 review 是否為『新版結構化評論』型態。"""
    hits = sum(1 for pat in _COMPILED if pat.search(text))
    return hits >= 2


def split_text_and_block(text: str) -> Tuple[str, str]:
    """
    將一整段 review 切成：
      - free_text: 一般敘述文字
      - structured_block: 下面這種 menu-like 結構

        Meal type: Lunch
        Price per person: $100+
        Food: 5
        Service: 5
        ...

    不需要解析欄位，純粹做分段。
    """
    if not text:
        return "", ""

    # 你可以用更精緻的切法，這裡先保留簡單版 idea：
    lines = text.splitlines()
    free_lines = []
    block_lines = []
    in_block = False

    for line in lines:
        if any(pat.search(line) for pat in _COMPILED):
            in_block = True
        if in_block:
            block_lines.append(line)
        else:
            free_lines.append(line)

    return "\n".join(free_lines).strip(), "\n".join(block_lines).strip()
