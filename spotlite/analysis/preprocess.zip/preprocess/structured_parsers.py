# spotlite/analysis/preprocess/structured_parsers.py
from __future__ import annotations
from abc import ABC, abstractmethod
from typing import Dict, Any, List
import re


class StructuredReviewParser(ABC):
    """不同 domain / source（餐廳 / 飯店 / airline）的結構化評論 parser 基底。"""

    @abstractmethod
    def parse_block(self, block: str) -> Dict[str, Any]:
        """把結構化 block 文字解析成一個 dict。"""
        raise NotImplementedError


class RestaurantGMapStructuredParser(StructuredReviewParser):
    """
    專門處理 Google Maps 餐廳的『新版結構化評論』。
    """

    # 簡易 regex，之後你可以逐步加強
    FIELD_PATTERNS = {
        "meal_type": r"Meal type:\s*(.+)",
        "price_per_person": r"Price per person:\s*\$?(.+)",
        "food_score": r"Food:\s*([0-9])",
        "service_score": r"Service:\s*([0-9])",
        "atmosphere_score": r"Atmosphere:\s*([0-9])",
        "noise_level": r"Noise level:\s*(.+)",
        "wait_time": r"Wait time:\s*(.+)",
        "parking_space": r"Parking space:\s*(.+)",
        "parking_options": r"Parking options:\s*(.+)",
        "recommended_dishes": r"Recommended dishes?:\s*(.+)",
    }

    def parse_block(self, block: str) -> Dict[str, Any]:
        data: Dict[str, Any] = {}
        if not block:
            return data

        for key, pattern in self.FIELD_PATTERNS.items():
            m = re.search(pattern, block, flags=re.IGNORECASE)
            if not m:
                continue
            val = m.group(1).strip()
            if key.endswith("_score"):
                try:
                    data[key] = int(val)
                except ValueError:
                    data[key] = None
            elif key == "recommended_dishes":
                # 逗號分隔，簡單切
                dishes = [x.strip()
                          for x in re.split(r"[，,;/]", val) if x.strip()]
                data[key] = dishes
            else:
                data[key] = val

        return data
